class Sig:
	TransOutputSpeed = 0
	TransTurbineSpeed = 1
	EngineSpeed = 2
	AccelPedalPosition = 3
	EngineStateVariable1 = 4
	MaxIndexInSigClass = 5
